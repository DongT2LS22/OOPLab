package test.cart;

import aims.cart.Cart;
import aims.media.DigitalVideoDisc;

public class CartTest {
        public static void main(String[] args) {

//                Cart anOrder = new Cart();
//
//                DigitalVideoDisc dvd1 = new DigitalVideoDisc("Toi thay hoa vang tren co xanh", "Truyen ngan",
//                                "Nguyen Nhat Anh", 200, 21.05);
//                anOrder.addDigitalVideoDisc(dvd1);
//
//                anOrder.displayCart();
//
//                DigitalVideoDisc dvd2 = new DigitalVideoDisc("Star Wars", "Science Fiction",
//                                "George Lucas", 127, 24.95);
//                anOrder.addDigitalVideoDisc(dvd2);
//
//                DigitalVideoDisc dvd3 = new DigitalVideoDisc("Aladin", "Animation", 18.99);
//                anOrder.addDigitalVideoDisc(dvd3);
//
//                anOrder.printCart();
//
//                System.out.println("Total cost: " + anOrder.totalCost());
        }

}
